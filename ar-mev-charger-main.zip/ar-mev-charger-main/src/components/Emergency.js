export default function Emergency () {
  return (
    <div>
      <h1>Emergency</h1>
    </div>
  )
}
